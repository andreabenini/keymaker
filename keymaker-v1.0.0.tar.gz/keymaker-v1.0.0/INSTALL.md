# Keymaker Firmware Installation Guide

This guide will help you install the Keymaker firmware on your ESP32 device (CYD - Cheap Yellow Display).

## Quick Start (Automatic Setup)

The installer now automatically sets up everything for you!

### Requirements
- **Python 3.6+** (check with `python3 --version`)
- **USB cable** to connect your ESP32

### Installation

1. **Download and extract** the firmware package
2. **Connect** your ESP32 via USB
3. **Run the installer:**
   ```bash
   ./install_firmware.sh
   ```

That's it! The installer will:
- ✓ Automatically create a Python virtual environment
- ✓ Install esptool and dependencies
- ✓ Detect your ESP32 device
- ✓ Flash the firmware

## Detailed Guide

### Prerequisites

#### Python 3
You need Python 3.6 or later installed on your system.

**Check if Python is installed:**
```bash
python3 --version
```

**If not installed:**
- **Linux (Debian/Ubuntu)**: `sudo apt install python3 python3-venv`
- **Linux (Fedora)**: `sudo dnf install python3`
- **macOS**: `brew install python3` (requires [Homebrew](https://brew.sh))

### Installation Steps

### Step 1: Download Firmware

Download the firmware package which contains:
- `install_firmware.sh` - Automatic installation script
- `requirements.txt` - Python dependencies
- `QUICK_START.txt` - Quick reference guide
- `build/` directory with firmware files

### Step 2: Connect Your ESP32

1. Connect your ESP32 device to your computer using a USB cable
2. The device should appear as a serial port:
   - **Linux**: `/dev/ttyUSB0` or `/dev/ttyACM0`
   - **macOS**: `/dev/cu.usbserial-*` or similar

### Step 3: Fix Permissions (Linux only)

If you're on Linux, you may need to add yourself to the `dialout` group to access the serial port:

```bash
sudo usermod -a -G dialout $USER
```

Then log out and log back in for the changes to take effect.

### Step 4: Run the Installer

**Automatic port detection:**
```bash
./install_firmware.sh
```

The script will try to automatically detect your ESP32 device.

**Manual port specification:**
```bash
./install_firmware.sh /dev/ttyUSB0
```

Replace `/dev/ttyUSB0` with your actual port.

### Step 5: Follow the Prompts

The installer will:
1. ✓ Set up Python virtual environment (first run only)
2. ✓ Install esptool automatically (first run only)
3. ✓ Verify all firmware files are present
4. ✓ Detect or ask for the USB port
5. ✓ Read chip information
6. ⚠ Ask for confirmation before flashing
7. ⚡ Flash the firmware (takes about 30 seconds)

The first run takes a bit longer as it sets up the environment, but subsequent runs are instant.

## Manual Installation (Advanced)

If you prefer to install dependencies manually:

```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run installer
./install_firmware.sh
```

## Troubleshooting

### "Python 3 is not installed"
The installer needs Python 3. Install it for your system:
- **Linux (Debian/Ubuntu)**: `sudo apt install python3 python3-venv`
- **Linux (Fedora)**: `sudo dnf install python3`
- **macOS**: `brew install python3`

### Virtual environment issues
If automatic setup fails, try manual installation:
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
./install_firmware.sh
```

### "Permission denied" on Linux
Add yourself to the dialout group:
```bash
sudo usermod -a -G dialout $USER
```
Then log out and log back in.

### "Port does not exist"
- Make sure the ESP32 is connected via USB
- Check which port your device is using:
  - **Linux**: `ls /dev/ttyUSB* /dev/ttyACM*`
  - **macOS**: `ls /dev/cu.*`
- Specify the correct port manually: `./install_firmware.sh <port>`

### "Failed to communicate with ESP32"
1. Try pressing and holding the **BOOT** button on the ESP32
2. While holding BOOT, press the **RESET** button
3. Release RESET, then release BOOT
4. Run the installer again

### Multiple USB devices detected
If you have multiple USB serial devices, specify the correct one:
```bash
./install_firmware.sh /dev/ttyUSB0
```

## Monitoring the Device

After flashing, you can monitor the serial output to see your device boot up:

```bash
esptool.py --port /dev/ttyUSB0 monitor
```

Press `Ctrl+]` to exit the monitor.

## What Gets Flashed?

The installer flashes three components to your ESP32:

| Component | Flash Address | Description |
|-----------|---------------|-------------|
| Bootloader | 0x1000 | ESP32 bootloader |
| Partition Table | 0x8000 | Memory layout configuration |
| Keymaker App | 0x10000 | Main OTP authenticator application |

Flash settings:
- **Mode**: DIO
- **Frequency**: 40MHz
- **Size**: 4MB

## Need Help?

If you encounter issues:
1. Check the [Troubleshooting](#troubleshooting) section above
2. Open an issue on GitHub
3. Make sure your ESP32 is a genuine ESP32-WROOM-32 (CYD compatible)

## License

Keymaker is dual-licensed under GPLv3 for open-source use and commercial licensing for proprietary products. See the main README for details.
